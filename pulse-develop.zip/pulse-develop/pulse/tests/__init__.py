# Tests for Pulse application
