# Copyright (c) 2026, Frappe and contributors
# For license information, please see license.txt
"""Invoice, forecast, credit-ledger reads + wallet top-up / settlement actions.

Top-ups credit the wallet only after the gateway confirms the money moved
(create_topup_order opens the gateway order; confirm_topup verifies it).
"""

import frappe
from frappe import _
from frappe.rate_limiter import rate_limit

from central.billing import authz
from central.billing.api.dashboard._shared import (
	_describe_line,
	_enabled_gateway_for_currency,
	_gateway_for_currency,
	_paypal_gateway_for_currency,
	_project_titles,
	_require_billing_setup,
	_require_manage,
	_require_view,
	_resolve_team,
	_team_currency,
)
from central.billing.doctype.top_up_order.top_up_order import TopupOrder
from central.billing.gateways.base import VerifiedPayment
from central.billing.revenue import credits


@frappe.whitelist()
def get_forecast(team: str | None = None) -> dict:
	"""Current-month forecast: projected month-end bill vs credit balance.

	Driven by the same engine billing uses — fixed accrual from the price-lock
	segments (active resources projected to month-end) plus metered overage from
	the running-total rollups.
	"""
	team = _resolve_team(team)
	today = frappe.utils.getdate()
	month_start = frappe.utils.get_first_day(today)
	month_end = frappe.utils.get_last_day(today)

	# The customer's forecast is a projection under one fixed scenario: this team, this
	# month, live configuration, everything settles. Running it through the same engine
	# an operator simulates with is what stops the two numbers drifting apart — there is
	# no second rating path to keep in step.
	from central.billing.projection import engine

	# Not strictly guarded: this is a customer page, and it must not fail because the
	# request that reached it happened to write something first.
	projection = engine.project(team, month_start, month_end, today=today, mode="Optimistic", guarded=False)
	invoice = projection["invoice"] or {}
	line_items = invoice.get("lines") or []

	subtotal = frappe.utils.flt(invoice.get("subtotal"))
	projected_total = frappe.utils.flt(invoice.get("total"))
	credit_balance = frappe.utils.flt(credits.get_balance(team)["balance"])
	shortfall = max(0.0, frappe.utils.flt(projected_total - credit_balance, 2))
	currency = projection["currency"] or _team_currency(team)
	tax = {
		"output_tax_amount": frappe.utils.flt(invoice.get("output_tax_amount")),
		"output_tax_type": invoice.get("output_tax_type"),
	}

	return {
		"period_start": str(month_start),
		"period_end": str(month_end),
		"projected_total": projected_total,
		"subtotal": subtotal,
		# Never quote the projection as a bare number: the engine already knows which
		# part of it is owed and which is inferred, and the customer is owed the split
		# (projection/basis.py).
		# Last month's bill, so the projection can be read as a change rather than a
		# number in isolation — "is this going up" is what the figure is looked at
		# for, and it cannot be answered from one month alone.
		**_previous_month(team, month_start),
		"measured": frappe.utils.flt(invoice.get("measured")),
		"estimated": frappe.utils.flt(invoice.get("estimated")),
		"has_estimates": bool(invoice.get("has_estimates")),
		"tax_amount": tax["output_tax_amount"],
		"tax_type": tax["output_tax_type"],
		"credit_balance": credit_balance,
		"shortfall": shortfall,
		"days_remaining": (month_end - today).days,
		"currency": currency,
		# Warn when the projected bill outruns the wallet (a top-up may be due).
		"credit_alert": shortfall > 0,
		# Spell out each service/plan + metered overage driving the projection.
		"line_items": [_describe_line(team, frappe._dict(li)) for li in line_items],
	}


def _previous_month(team: str, month_start) -> dict:
	"""What the month before this one actually came to, and what to call it.

	Compared like for like: a full projected month against a full billed one, both
	inclusive of tax. Cancelled invoices are not a bill anyone paid, and a period
	the team was not billed for is simply absent — a comparison against zero would
	read as though spend had exploded.
	"""
	previous_start = frappe.utils.add_months(month_start, -1)
	total = frappe.db.get_value(
		"Invoice",
		{
			"team": team,
			"invoice_type": "Billable",
			"status": ["!=", "Cancelled"],
			"period_start": previous_start,
		},
		"total",
	)
	if not total:
		return {"previous_total": None, "previous_label": None}
	return {
		"previous_total": frappe.utils.flt(total),
		"previous_label": frappe.utils.getdate(previous_start).strftime("%B"),
	}


@frappe.whitelist()
def list_subscriptions(team: str | None = None) -> list[dict]:
	"""Active per-server subscriptions, enriched for display: the server's friendly
	name, its plan title, a human region label, and the resolved monthly price — the
	fields the dashboard renders instead of the raw hashes."""
	team = _resolve_team(team)
	from central.billing.regions import region_label

	rows = frappe.get_all(
		"Subscription",
		filters={"team": team},
		fields=[
			"name",
			"plan",
			"pricing_mode",
			"sub_category",
			"cluster",
			"server_id",
			"service_subject",
			"billing_cycle",
			"account_standing",
			"start_date",
			"enabled",
			"project",
		],
		order_by="creation desc",
	)
	currency = _team_currency(team)
	project_titles = _project_titles(r.project for r in rows)
	# Batch the server lookup so a team with N subscriptions costs one query, not N.
	server_ids = list({r.server_id for r in rows if r.server_id})
	servers = (
		{
			a.name: a
			for a in frappe.get_all(
				"Virtual Machine",
				filters={"name": ["in", server_ids]},
				fields=["name", "title", "gateway_url", "status"],
			)
		}
		if server_ids
		else {}
	)
	# A composed config carries no Plan: its price is the locked rate of its open
	# billing segment (ADR 0010), and its "plan title" is a spec line built from the
	# composition. Batch both so a team with N composed configs stays O(1) queries.
	composed = [r.name for r in rows if r.pricing_mode == "Composed"]
	includes_by_sub = _composed_includes(composed)
	# The open segment's locked rate is what this team is actually billed (ADR 0010),
	# preset and composed alike. Read for every row, not only composed ones: quoting
	# a preset at today's catalog rate shows a grandfathered customer a price they
	# will never be charged.
	segment_rate = _open_segment_rates(team)

	plan_titles: dict[str, str] = {}
	rate_cache: dict[tuple, float | None] = {}
	out = []
	for r in rows:
		server = servers.get(r.server_id) or frappe._dict()
		if r.pricing_mode == "Composed":
			plan_title = _composed_label(r.sub_category, includes_by_sub.get(r.name, []))
			monthly_rate = segment_rate.get(r.name)
		else:
			if r.plan and r.plan not in plan_titles:
				plan_titles[r.plan] = frappe.db.get_value("Plan", r.plan, "title") or r.plan
			key = (r.plan, r.cluster)
			if r.plan and key not in rate_cache:
				rate_cache[key] = frappe.get_doc("Plan", r.plan).get_rate(currency, r.cluster)
			plan_title = plan_titles.get(r.plan)
			# Catalog rate only as the fallback, for a subscription with no open
			# segment yet (never provisioned, or cancelled).
			monthly_rate = segment_rate.get(r.name)
			if monthly_rate is None:
				monthly_rate = rate_cache.get(key)
		out.append(
			{
				"name": r.name,
				# What metering and the cycle-cost read key on: a Virtual Machine-backed
				# subscription by its server, a team-level service by its synthesized
				# subject (ADR 0013). Lets the card join a row to what it cost.
				"resource_id": r.server_id or r.service_subject,
				"server": server.title or None,
				# VirtualMachine-backed = a real server; a subscription without one is a
				# team-level metered service (the dashboard lists those separately).
				"has_server": bool(r.server_id),
				"gateway_url": server.gateway_url or None,
				# The VM's operational state (Running/Stopped/Terminated/…) — the list shows
				# it distinctly from the billing-paused flag, and gates resume on it.
				"status": server.status or None,
				"plan": r.plan,
				"plan_title": plan_title,
				"cluster": r.cluster,
				"region": region_label(r.cluster),
				"billing_cycle": r.billing_cycle,
				"account_standing": r.account_standing,
				"enabled": r.enabled,
				"monthly_rate": monthly_rate,
				"currency": currency,
				"project": r.project,
				"project_title": project_titles.get(r.project),
			}
		)
	return out


def _composed_includes(subscription_names: list[str]) -> dict[str, list]:
	"""The composition rows (qty per Resource Type) for each composed subscription, in
	one batched query — keyed by subscription name."""
	if not subscription_names:
		return {}
	by_sub: dict[str, list] = {}
	for row in frappe.get_all(
		"Plan Includes",
		filters={"parenttype": "Subscription", "parent": ["in", subscription_names]},
		fields=["parent", "resource_type", "quantity", "unit"],
	):
		by_sub.setdefault(row.parent, []).append(row)
	return by_sub


def _open_segment_rates(team: str) -> dict[str, float]:
	"""subscription -> its open segment's locked rate, the authoritative billed price
	(ADR 0010), for the team's subscriptions in one batched read."""
	from central.billing.catalog.subscriptions import team_active_segments

	return {s.subscription: s.locked_rate for s in team_active_segments(team)}


def _composed_label(sub_category: str | None, includes: list) -> str:
	"""A composed config's display title, mirroring a preset's 'Profile — specs' shape,
	e.g. 'General — 1 vCPU · 4 GB RAM · 40 GB disk'."""
	from central.billing.catalog.composition import config_summary

	summary = config_summary(includes)
	if sub_category and summary:
		return f"{sub_category} — {summary}"
	return summary or "Custom config"


@frappe.whitelist(methods=["POST"])
def pause_subscription(subscription: str, team: str | None = None) -> dict:
	"""Pause billing for a subscription (records intent + disables it, ADR 0006)."""
	owner = frappe.db.get_value("Subscription", subscription, "team")
	_require_manage(owner)
	from central.billing.catalog import subscriptions

	doc = subscriptions.pause_billing(subscription)
	return {"name": doc.name, "enabled": doc.enabled}


@frappe.whitelist(methods=["POST"])
def resume_subscription(subscription: str, team: str | None = None) -> dict:
	"""Resume billing for a paused subscription."""
	owner = frappe.db.get_value("Subscription", subscription, "team")
	_require_manage(owner)
	from central.billing.catalog import subscriptions

	doc = subscriptions.resume_billing(subscription)
	return {"name": doc.name, "enabled": doc.enabled}


@frappe.whitelist(methods=["POST"])
def set_subscription_project(subscription: str, project: str | None = None) -> dict:
	"""Tag a subscription into a Project, or clear it (`project=None`) back to
	untagged. `Subscription.validate_project` is the authority on same-team /
	enabled / spending-limit headroom — this only gates who may call it."""
	owner = frappe.db.get_value("Subscription", subscription, "team")
	_require_manage(owner)
	doc = frappe.get_doc("Subscription", subscription)
	doc.project = project or None
	doc.save(ignore_permissions=True)
	return {"name": doc.name, "project": doc.project}


@frappe.whitelist()
def list_invoices(team: str | None = None) -> list[dict]:
	"""Invoice history — summary only (no internal/admin fields)."""
	team = _resolve_team(team)
	rows = frappe.get_all(
		"Invoice",
		filters={"team": team},
		fields=[
			"name",
			"period_start",
			"period_end",
			"status",
			"invoice_type",
			"total",
			"amount_paid",
			"currency",
			"due_date",
			"erpnext_invoice",
		],
		order_by="period_start desc",
	)
	for row in rows:
		row["has_pdf"] = bool(row.pop("erpnext_invoice"))
	return rows


@frappe.whitelist(methods=["GET"])
@rate_limit(limit=30, seconds=60 * 60)
def download_invoice_pdf(name: str) -> None:
	"""The customer's copy of the statutory invoice, as ERPNext renders it."""
	from central.billing.ingester.erpnext_sync import sales_invoice_pdf

	team, sales_invoice = frappe.db.get_value("Invoice", name, ["team", "erpnext_invoice"]) or (None, None)
	_require_view(team)
	if not sales_invoice:
		frappe.throw(_("This invoice has not been issued yet, so it has no PDF."), frappe.DoesNotExistError)
	frappe.local.response.filename = f"{sales_invoice.replace('/', '-')}.pdf"
	frappe.local.response.filecontent = sales_invoice_pdf(sales_invoice)
	frappe.local.response.type = "download"


@frappe.whitelist()
def get_invoice(name: str) -> dict:
	"""One invoice with line items + tax block, scoped to the caller's team."""
	team = frappe.db.get_value("Invoice", name, "team")
	_require_view(team)
	doc = frappe.get_doc("Invoice", name)
	from central.billing.payments.charges import in_flight_attempt

	# An attempt already charging (or captured and awaiting the settlement webhook)
	# means the money is moving — the UI must show a "settling" state, not a Pay
	# button, so the customer can't fire a second charge (#10).
	payment_in_progress = bool(in_flight_attempt(name))

	# Which method settled it — a quiet receipt line on the paid invoice. Read
	# from the capturing attempt (not the team's current default), so history
	# stays true after the method is replaced.
	paid_with = None
	if doc.status == "Paid":
		method = frappe.db.get_value(
			"Payment Attempt",
			{"invoice": name, "status": "Captured"},
			"payment_method",
			order_by="creation desc",
		)
		pm = (
			frappe.db.get_value("Payment Method", method, ["display_label", "method_type"], as_dict=True)
			if method
			else None
		)
		if pm:
			paid_with = {"label": pm.display_label, "method_type": pm.method_type}

	return {
		"name": doc.name,
		"team": doc.team,
		"status": doc.status,
		"invoice_type": doc.invoice_type,
		"period_start": str(doc.period_start),
		"period_end": str(doc.period_end),
		"currency": doc.currency,
		"subtotal": doc.subtotal,
		"output_tax_type": doc.output_tax_type,
		"output_tax_rate": doc.output_tax_rate,
		"output_tax_amount": doc.output_tax_amount,
		"zero_rating_reason": doc.zero_rating_reason,
		"total": doc.total,
		"credit_applied": doc.credit_applied,
		"advance_tax_applied": doc.advance_tax_applied,
		"expected_collection": doc.expected_collection,
		"amount_paid": doc.amount_paid,
		"due_date": str(doc.due_date) if doc.due_date else None,
		"has_pdf": bool(doc.erpnext_invoice),
		"payment_in_progress": payment_in_progress,
		"paid_with": paid_with,
		"items": [_describe_line(doc.team, li) for li in doc.items],
		"activity": _invoice_activity(doc),
	}


_PAYMENT_TITLES = {
	"Captured": "Card payment captured",
	"Failed": "Card payment failed",
	"Initiated": "Card payment initiated",
	"Authorised": "Card payment authorised",
	"Refunded": "Payment refunded",
}


def _invoice_activity(doc) -> list[dict]:
	"""Full lifecycle of one invoice as a timeline: finalised → credits applied →
	card attempts (incl. failed retries) → settled. This is the per-invoice
	payment history shown inside the invoice (no separate tab)."""
	events = [
		{
			"at": str(doc.creation),
			"kind": "issued",
			"title": "Invoice finalised",
			"detail": f"{doc.invoice_type} · {doc.period_start} → {doc.period_end}",
			"amount": frappe.utils.flt(doc.total),
			"currency": doc.currency,
			"theme": "gray",
		}
	]

	for e in frappe.get_all(
		"Credit Ledger Entry",
		filters={"reference_type": "Invoice", "reference_name": doc.name, "entry_type": "Debit"},
		fields=["amount", "currency", "created_at", "creation", "note"],
		order_by="creation asc",
	):
		events.append(
			{
				"at": str(e.created_at or e.creation),
				"kind": "credit",
				"title": "Credits applied",
				"detail": "Drawn from wallet balance",
				"amount": frappe.utils.flt(e.amount),
				"currency": e.currency,
				"theme": "blue",
			}
		)

	for p in frappe.get_all(
		"Payment Attempt",
		filters={"invoice": doc.name},
		fields=[
			"status",
			"amount",
			"currency",
			"gateway",
			"gateway_transaction_id",
			"failure_code",
			"failure_reason",
			"retry_number",
			"initiated_at",
			"completed_at",
			"creation",
		],
		order_by="creation asc",
	):
		failed = p.status == "Failed"
		detail = (
			p.failure_reason
			if failed
			else (f"Txn {p.gateway_transaction_id}" if p.gateway_transaction_id else p.gateway)
		)
		if p.retry_number:
			detail = f"{detail or ''} · retry #{p.retry_number}".strip(" ·")
		events.append(
			{
				"at": str(p.completed_at or p.initiated_at or p.creation),
				"kind": "payment",
				"title": _PAYMENT_TITLES.get(p.status, f"Card payment {str(p.status).lower()}"),
				"detail": detail,
				"amount": frappe.utils.flt(p.amount),
				"currency": p.currency,
				"theme": "green" if p.status == "Captured" else ("red" if failed else "orange"),
			}
		)

	events.sort(key=lambda x: x["at"])

	# Closure marker, pinned to the last real event so it stays the newest event —
	# the list is returned newest-first, so this reads at the top.
	if doc.status == "Paid":
		events.append(
			{
				"at": events[-1]["at"] if events else str(doc.creation),
				"kind": "paid",
				"title": "Invoice settled",
				"detail": None,
				"amount": frappe.utils.flt(doc.total),
				"currency": doc.currency,
				"theme": "green",
			}
		)

	for e in events:
		e["at"] = _fmt_when(e["at"])
	events.reverse()  # newest first — the latest state reads at the top
	return events


def _fmt_when(dt) -> str | None:
	if not dt:
		return None
	try:
		return frappe.utils.get_datetime(dt).strftime("%d %b %Y, %H:%M")
	except Exception:
		return str(dt)


@frappe.whitelist()
def list_payment_attempts(team: str | None = None, limit: int = 100) -> list[dict]:
	"""Payment attempt history — every charge against the team's card/mandate,
	including the failed dunning retries that lead to suspension. This is the
	customer's record of WHY a card-on-file team can still be past_due/suspended.
	"""
	from central.billing.payments import decline

	team = _resolve_team(team)
	rows = frappe.get_all(
		"Payment Attempt",
		filters={"team": team},
		fields=[
			"name",
			"status",
			"amount",
			"currency",
			"gateway",
			"invoice",
			"failure_code",
			"failure_reason",
			"retry_number",
			"gateway_transaction_id",
			"initiated_at",
			"completed_at",
			"creation",
		],
		limit=limit,
	)
	for row in rows:
		# When the payment actually happened, not when we wrote the row. `creation`
		# is the insert time, which for any backfilled or migrated attempt is simply
		# the day it was imported — every attempt then reads as though it happened
		# today. Same precedence the invoice timeline uses.
		row["at"] = str(row.completed_at or row.initiated_at or row.creation)
		# `failure_reason` is the gateway's own wording. Keep it (support quotes it)
		# but lead with something the cardholder can act on.
		row["reason"] = decline.customer_reason(row.failure_code) if row.status == "Failed" else None
	# Sorted on that same resolved time — ordering by `creation` put a backfilled
	# year of attempts in whatever order they happened to be inserted.
	rows.sort(key=lambda r: r["at"], reverse=True)
	return rows


@frappe.whitelist()
def get_credit_balance(team: str | None = None) -> dict:
	"""The wallet balance, and how much of it is promotional credit on a clock.

	`expiring` is one row per grant that still has an expiry ahead of it, soonest
	first, so the customer can see what they stand to lose and when. Purchased
	credit never appears there — it doesn't expire."""
	team = _resolve_team(team)
	currency = _team_currency(team)
	return {
		"balance": frappe.utils.flt(credits.get_balance(team)["balance"]),
		"currency": currency,
		"expiring": credits.expiring_credits(team, currency),
	}


@frappe.whitelist()
def credit_ledger(team: str | None = None, limit: int = 50) -> list[dict]:
	team = _resolve_team(team)
	rows = frappe.get_all(
		"Credit Ledger Entry",
		filters={"team": team},
		fields=[
			"name",
			"entry_type",
			"amount",
			"tax_amount",
			"running_balance",
			"currency",
			"note",
			"created_at",
			"reference_type",
			"reference_name",
			"advance_id",
		],
		order_by="creation desc",
		limit=limit,
	)
	for row in rows:
		# A top-up booked in the accounting system has a receipt to download.
		row["has_receipt"] = bool(row.pop("advance_id"))
	return rows


@frappe.whitelist(methods=["GET"])
@rate_limit(limit=30, seconds=60 * 60)
def download_topup_receipt(name: str) -> None:
	"""The receipt voucher for a wallet top-up, as the accounting system renders it."""
	from central.billing.ingester.advance import receipt_pdf

	team, advance_id = frappe.db.get_value("Credit Ledger Entry", name, ["team", "advance_id"]) or (
		None,
		None,
	)
	_require_view(team)
	if not advance_id:
		frappe.throw(_("This top-up has no receipt yet."), frappe.DoesNotExistError)
	frappe.local.response.filename = f"{advance_id.replace('/', '-')}.pdf"
	frappe.local.response.filecontent = receipt_pdf(advance_id)
	frappe.local.response.type = "download"


@frappe.whitelist(methods=["POST"])
def pay_invoice(invoice: str | None = None) -> dict:
	"""Postpaid one-off settlement of an outstanding invoice (team-scoped)."""
	team = frappe.db.get_value("Invoice", invoice, "team")
	_require_manage(team)
	from central.billing.payments import charges

	return charges.pay_invoice(invoice)


@frappe.whitelist()
def get_fallback_offer(invoice: str | None = None) -> dict:
	"""The other rail to offer after a card was finally refused (ADR 0022).

	Returns the instrument to put one tap away, with the amount already filled in,
	so the customer never meets an empty second card form. Empty where the last
	attempt is not a terminal decline: a timeout may still settle at the gateway,
	and charging a second rail on top of it pays one invoice twice.
	"""
	team = frappe.db.get_value("Invoice", invoice, "team")
	_require_manage(team)
	from central.billing.payments import decline

	inv = frappe.db.get_value("Invoice", invoice, ["currency", "expected_collection"], as_dict=True)
	last = frappe.get_all(
		"Payment Attempt",
		filters={"invoice": invoice},
		fields=["gateway", "status", "failure_code"],
		order_by="creation desc",
		limit=1,
	)
	if not last or last[0].status != "Failed" or not decline.is_terminal(last[0].failure_code):
		return {"offer": None}

	tile = decline.alternate_rail(team, inv.currency, last[0].gateway)
	if not tile:
		return {"offer": None}
	return {
		"offer": tile,
		"amount": frappe.utils.flt(inv.expected_collection),
		"currency": inv.currency,
	}


@frappe.whitelist(methods=["POST"])
def pay_invoice_checkout(invoice: str | None = None) -> dict:
	"""Open an on-session gateway checkout to pay an invoice yourself
	(collection_mode = manual_checkout). Any amount — on-session has no ₹15k limit."""
	team = frappe.db.get_value("Invoice", invoice, "team")
	_require_manage(team)
	from central.billing.payments import charges

	return charges.create_invoice_payment_order(invoice)


@frappe.whitelist(methods=["POST"])
def confirm_invoice_checkout(
	attempt: str | None = None,
	razorpay_order_id: str | None = None,
	razorpay_payment_id: str | None = None,
	razorpay_signature: str | None = None,
) -> dict:
	"""Verify the on-session checkout callback; the invoice settles on the webhook."""
	team = frappe.db.get_value("Payment Attempt", attempt, "team")
	_require_manage(team)
	from central.billing.payments import charges

	return charges.confirm_invoice_payment(
		attempt,
		razorpay_order_id=razorpay_order_id,
		razorpay_payment_id=razorpay_payment_id,
		razorpay_signature=razorpay_signature,
	)


@frappe.whitelist()
def get_topup_options(team: str | None = None) -> dict:
	"""The instruments a wallet recharge can be paid with (ADR 0023).

	A different list from the mandate surface: this one pays once with the customer
	present, so netbanking belongs here and a card of any network Stripe accepts is
	fine. `publishable_key` is returned for the Stripe rail, which collects the card
	in-app rather than redirecting.
	"""
	team = _resolve_team(team)
	currency = _team_currency(team)
	from central.billing.payments import instruments as instrument_catalogue

	tiles = instrument_catalogue.available(currency, instrument_catalogue.RECHARGE)
	publishable_key = None
	card_gw = _enabled_gateway_for_currency(currency, "Stripe")
	if card_gw:
		from central.billing.gateways.registry import get_adapter

		publishable_key = get_adapter(frappe.get_doc("Payment Gateway", card_gw)).get_credential("api_key")
	return {
		"currency": currency,
		"instruments": tiles,
		"publishable_key": publishable_key,
		# GST charged on top of a top-up, as a percentage. 0 where none applies.
		"gst_rate": frappe.utils.flt(credits.top_up_gst_rate(team) * 100, 2),
	}


@frappe.whitelist(methods=["POST"])
def create_topup_order(
	team: str | None = None,
	amount: float | None = None,
	gateway: str | None = None,
	method: str | None = None,
	instrument: str | None = None,
) -> dict:
	"""Start a wallet top-up by creating a real gateway order. The UI opens the
	gateway's checkout against it; the wallet is credited only after the gateway
	confirms (verify in confirm_topup) — never magically.

	`method="paypal"` routes an international top-up to the configured PayPal gateway
	(non-INR card default stays Stripe). That gateway's `paypal_settlement_mode` then
	picks the rail:
	  - Direct: PayPal's own merchant account; the SPA renders PayPal Buttons and the
	    capture id reconciles against PayPal's ledger (ADR 0007).
	  - Via Razorpay: PayPal is collected inside the Razorpay sheet and settles through
	    Razorpay (ADR 0005). The order is created on the currency's Razorpay gateway and
	    `display_paypal` tells the SPA to surface the PayPal block in that sheet; the
	    reference stored is the razorpay_payment_id."""
	team = _resolve_team(team, authz.MANAGE)
	_require_billing_setup(team)
	amount = frappe.utils.flt(amount)
	if amount <= 0:
		frappe.throw(_("Top-up amount must be greater than zero."), frappe.ValidationError)
	currency = _team_currency(team)
	gw, display_paypal = _top_up_gateway(currency, gateway, method, instrument)
	from central.billing.gateways.registry import get_adapter

	gw_doc = frappe.get_doc("Payment Gateway", gw)
	adapter = get_adapter(gw_doc)
	# Mint-or-reuse the team's customer at this gateway *before* the order, so the
	# top-up attaches to the one customer every later charge reuses (the card #05 and
	# mandate #08 paths share this same Gateway Customer row). ensure_gateway_customer
	# commits the row the instant it mints, so a failed order can't orphan it.
	from central.billing.gateways.base import customer_safe_gateway_errors
	from central.billing.payments.payments import ensure_gateway_customer

	with customer_safe_gateway_errors():
		customer_id = ensure_gateway_customer(team, gw, adapter)
	# Both rails collect the card in-app: Razorpay in its hosted sheet over the
	# returned order, Stripe via a PaymentIntent the SPA confirms with Stripe.js
	# (no hosted-Checkout redirect). The India-export billing address rides on the
	# Stripe PaymentIntent from the Billing Profile, so it's never re-asked.
	# GST is charged on top of the credit. The wallet gets the credit, and the GST
	# is held to pay the GST of the invoices the credit is used for.
	gst = credits.top_up_gst(team, amount)
	total = frappe.utils.flt(amount + gst, 2)
	# The split is stored on the order before the payer acts, so the wallet gets what
	# was ordered even if the tax rate changes before the payment is captured.
	order = TopupOrder.start(team, gw, currency, total, credit=amount, gst=gst)
	receipt = order.name
	with customer_safe_gateway_errors():
		handles = adapter.create_order(
			total, currency, receipt, notes={"team": team, "purpose": "wallet_topup"}, customer=customer_id
		)
	order.record_gateway_order(handles.get("order_id") or handles.get("payment_intent_id"))
	# The SPA branches on adapter_key: Stripe → PaymentIntent Element, Razorpay → hosted
	# sheet, Paypal → PayPal Buttons against the returned order_id (ADR 0007). For a
	# Via-Razorpay PayPal top-up the adapter_key is Razorpay (settlement runs there) and
	# display_paypal asks the sheet to surface the PayPal block.
	return {
		"gateway": gw,
		"adapter_key": gw_doc.adapter_key,
		"display_paypal": display_paypal,
		"amount": amount,
		"gst": gst,
		"total": total,
		"currency": currency,
		"receipt": receipt,
		**handles,
	}


def _top_up_gateway(
	currency: str, gateway: str | None, method: str | None, instrument: str | None
) -> tuple[str, bool]:
	"""The gateway a top-up goes to, and whether its sheet shows the PayPal block."""
	if method == "paypal":
		pp = frappe.get_doc("Payment Gateway", _paypal_gateway_for_currency(currency))
		if not pp.is_paypal_via_razorpay():
			return pp.name, False
		gw = _enabled_gateway_for_currency(currency, "Razorpay")
		if not gw:
			frappe.throw(
				_(
					"PayPal through Razorpay needs an enabled Razorpay gateway that supports {0}. Choose another payment method, or contact support."
				).format(currency),
				frappe.ValidationError,
			)
		return gw, True
	if not instrument:
		return gateway or _gateway_for_currency(currency), False

	# The recharge surface: the customer picked an instrument and that decides the
	# rail (ADR 0023). Resolving by currency default instead would put every INR
	# top-up on one provider, including the card ones Stripe should take.
	from central.billing.payments import instruments as instrument_catalogue

	gw = instrument_catalogue.gateway_for(instrument, currency, instrument_catalogue.RECHARGE)
	if not gw:
		frappe.throw(
			_("{0} isn't available for {1} top-ups.").format(instrument, currency),
			frappe.ValidationError,
		)
	return gw, False


@frappe.whitelist(methods=["POST"])
def confirm_topup(
	team: str | None = None,
	amount: float | None = None,
	gateway: str | None = None,
	razorpay_order_id: str | None = None,
	razorpay_payment_id: str | None = None,
	razorpay_signature: str | None = None,
	payment_intent: str | None = None,
	paypal_order_id: str | None = None,
) -> dict:
	"""Credit the wallet once the gateway confirms the payment for a top-up we stored.

	The payment is read back from the gateway, matched to the team's own Top-up Order by
	the gateway's order id, and must cover that order. Nothing the browser sends decides
	the team, the amount or the credit. `amount` is ignored and kept for older clients.
	The capture webhook credits through the same order, so the two book one credit."""
	team = _resolve_team(team, authz.MANAGE)
	from central.billing.gateways.registry import get_adapter

	gw_doc = frappe.get_doc("Payment Gateway", gateway)
	adapter = get_adapter(gw_doc)
	if gw_doc.adapter_key == "Paypal":
		order = _team_top_up_order(team, gw_doc.name, paypal_order_id)
		payment = _paypal_capture(adapter, paypal_order_id)
	elif gw_doc.adapter_key == "Razorpay":
		signed = adapter.verify_payment_signature(
			{
				"razorpay_order_id": razorpay_order_id,
				"razorpay_payment_id": razorpay_payment_id,
				"razorpay_signature": razorpay_signature,
			}
		)
		if not signed:
			_payment_not_confirmed()
		order = _team_top_up_order(team, gw_doc.name, razorpay_order_id)
		payment = adapter.verify_payment(razorpay_payment_id)
	else:
		order = _team_top_up_order(team, gw_doc.name, payment_intent)
		payment = adapter.verify_payment(payment_intent)
	return order.credit_wallet(payment)


def _team_top_up_order(team: str, gateway: str, gateway_order_id: str | None) -> TopupOrder:
	"""The caller's own top-up for this gateway order. Another team's order is not found."""
	name = gateway_order_id and frappe.db.get_value(
		"Top-up Order", {"team": team, "gateway": gateway, "gateway_order_id": gateway_order_id}, "name"
	)
	if not name:
		_payment_not_confirmed()
	return frappe.get_doc("Top-up Order", name)


def _paypal_capture(adapter, paypal_order_id: str) -> VerifiedPayment:
	"""Capture the order the buyer approved and read back what PayPal took."""
	capture = adapter.capture_order(paypal_order_id)
	return VerifiedPayment(
		payment_id=capture.get("id"),
		captured=capture.get("status") == "COMPLETED",
		amount=frappe.utils.flt(capture.get("amount")),
		currency=(capture.get("currency") or "").upper(),
		order_id=paypal_order_id,
	)


def _payment_not_confirmed():
	frappe.throw(
		_(
			"The payment could not be confirmed. Check your credit balance and payment history before paying again. Contact support if you were charged but no credit appears."
		),
		frappe.ValidationError,
	)
