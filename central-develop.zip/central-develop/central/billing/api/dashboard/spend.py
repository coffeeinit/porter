# Copyright (c) 2026, Frappe and contributors
# For license information, please see license.txt
"""What the team is paying for this cycle.

Derived from the same places billing itself reads — the projection engine for
money, the `Subscription Change` ledger for what is running (ADR 0010) — so a
customer never sees a number the monthly run would disagree with.

`list_rate_for` lives here too: it answers "what would this cost at today's
prices", which the resize disclosure needs to say what a resize gives up.
"""

import frappe

from central.billing.api.dashboard._shared import _resolve_team, _team_currency
from central.billing.catalog.subscriptions import team_active_segments


@frappe.whitelist()
def get_cycle_costs(team: str | None = None) -> dict:
	"""Everything being billed this cycle, with its month-to-date cost.

	Servers and team-level metered services in one list, because a customer asking
	"what am I paying for" does not care that one has a Virtual Machine behind it and the
	other is a synthesized subject (ADR 0013).
	"""
	team = _resolve_team(team)
	currency = _team_currency(team)
	today = frappe.utils.getdate()

	lines = _projected_lines(team, today)
	usage = _metered_usage(team)
	segments = {s.resource_id: s for s in team_active_segments(team) if s.resource_id}

	items = []
	for resource_id, cost in _cost_by_resource(lines).items():
		segment = segments.get(resource_id)
		items.append(
			{
				"resource_id": resource_id,
				"title": _title_for(resource_id, segment),
				"plan": segment.plan if segment else None,
				"cluster": segment.cluster if segment else None,
				"is_service": bool(segment and segment.service_subject),
				"amount": cost,
				"currency": currency,
				# Present only for a metered subject, and only where the plan bundles
				# an allowance — a draw-down bar is meaningless without a ceiling.
				"usage": usage.get(resource_id),
			}
		)

	items.sort(key=lambda i: i["amount"], reverse=True)
	return {
		"currency": currency,
		"items": items,
		"total": frappe.utils.flt(sum(i["amount"] for i in items), 2),
	}


def _projected_lines(team: str, today) -> list:
	"""This cycle's lines from the billing engine — the same ones the forecast quotes."""
	from central.billing.projection import engine

	projection = engine.project(
		team,
		frappe.utils.get_first_day(today),
		frappe.utils.get_last_day(today),
		today=today,
		guarded=False,
	)
	return (projection["invoice"] or {}).get("lines") or []


def _cost_by_resource(lines) -> dict:
	"""Sum line amounts per resource. A resize mid-cycle splits one resource across
	several lines, and a metered subject adds an overage line to its own bundle."""
	totals: dict = {}
	for line in lines:
		line = frappe._dict(line)
		resource_id = line.subscription_resource
		if not resource_id:
			continue
		totals[resource_id] = frappe.utils.flt(
			totals.get(resource_id, 0.0) + frappe.utils.flt(line.amount), 2
		)
	return totals


def _metered_usage(team: str) -> dict:
	"""Usage against the locked allowance, per metered subject, for this period."""
	usage: dict = {}
	rows = frappe.get_all(
		"Usage Rollup",
		filters={
			"team": team,
			"period_start": [">=", frappe.utils.get_first_day(frappe.utils.getdate())],
			"superseded_by": ["is", "not set"],
		},
		fields=["resource_id", "quantity", "unit", "locked_allowance"],
	)
	for row in rows:
		allowance = frappe.utils.flt(row.locked_allowance)
		if not allowance:
			continue
		current = usage.setdefault(row.resource_id, {"used": 0.0, "allowance": allowance, "unit": row.unit})
		current["used"] = frappe.utils.flt(current["used"] + frappe.utils.flt(row.quantity), 2)
	for entry in usage.values():
		entry["over"] = entry["used"] > entry["allowance"]
	return usage


def _title_for(resource_id: str, segment) -> str:
	"""What to call the thing on screen: the VirtualMachine's own name for a server, the plan
	title for a team-level service, and the raw subject only as a last resort."""
	if segment and segment.server_id:
		title = frappe.db.get_value("Virtual Machine", segment.server_id, "title")
		if title:
			return title
	if segment and segment.plan:
		title = frappe.db.get_value("Plan", segment.plan, "title")
		if title:
			return title
	return resource_id


def list_rate_for(segment, currency: str):
	"""What this subscription would cost if it were provisioned today.

	A preset resolves to its plan's catalog rate; a composed config is re-summed from
	the component rate card, because that is how it was priced in the first place
	(ADR 0009).
	"""
	from central.billing.catalog import pricing

	if segment.pricing_mode == "Composed":
		includes = frappe.get_all(
			"Plan Includes",
			filters={"parent": segment.subscription, "parenttype": "Subscription"},
			fields=["resource_type", "quantity"],
		)
		if not includes:
			return None
		return pricing.resolve_config_rate(includes, currency, segment.cluster)

	if not segment.plan:
		return None
	return pricing.resolve_rate(pricing.get_catalog_rates("Plan", segment.plan), currency, segment.cluster)


def _locked_at(subscription: str) -> str | None:
	"""When the open segment's rate was struck."""
	rows = frappe.get_all(
		"Subscription Change",
		filters={"subscription": subscription, "change_type": ["in", ("Created", "Plan Changed")]},
		fields=["effective_at"],
		order_by="effective_at desc, creation desc",
		limit=1,
	)
	return str(rows[0].effective_at) if rows and rows[0].effective_at else None
