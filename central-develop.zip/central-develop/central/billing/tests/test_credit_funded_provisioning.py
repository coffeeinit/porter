# Copyright (c) 2026, Frappe and contributors
# For license information, please see license.txt
"""Billing details and a payment method are asked for when credits stop covering
the bill, not before.

Provisioning is allowed while the wallet funds it; the invoice is held until the
details arrive.
"""

from unittest.mock import patch

import frappe

from central import resource_actions
from central.billing import settings
from central.billing.catalog.subscriptions import create_subscription
from central.billing.payments import profile, settlement
from central.billing.platform import alerts as billing_alerts
from central.billing.revenue import credits, invoicing
from central.billing.revenue.invoicing import run
from central.billing.tests.test_credits import run_workers
from central.billing.tests.utils import BillingTestCase as IntegrationTestCase
from central.billing.tests.utils import (
	complete_billing_profile,
	ensure_atlas_instance,
	ensure_team,
	make_plan,
	run_enqueued_inline,
	set_team_tier,
)
from central.infrastructure.doctype.resource_action.resource_action import ResourceAction

TEAM = "team-credit-funded"
REGION = "ap-south-1"
PLAN = "bundle-credit-funded"
RATE = 1500.0
COMPOSITION = [
	{"resource_type": "Compute", "quantity": 2, "unit": "vCPU"},
	{"resource_type": "Memory", "quantity": 4, "unit": "GB"},
	{"resource_type": "Disk", "quantity": 40, "unit": "GB"},
]


class CreditFundedTestBase(IntegrationTestCase):
	def setUp(self):
		ensure_team(TEAM)
		ensure_atlas_instance(REGION)
		self.plan = make_plan(
			PLAN, includes=COMPOSITION, rates=[{"cluster": "", "currency": "INR", "rate": RATE}]
		)
		self._purge()
		# A signup-shaped profile: the country and the currency it implies, and
		# nothing else — exactly what provision_signup_billing stamps from the IP.
		set_team_tier(TEAM, level="t0", max_spend=100000)
		frappe.set_user("Administrator")

	def tearDown(self):
		self._purge()

	def _purge(self):
		for dt in (
			"Invoice",
			"Credit Ledger Entry",
			"Billing Profile",
			"Billing Notification Log",
			"Team Notification",
			"Resource Action",
		):
			frappe.db.delete(dt, {"team": TEAM})
		frappe.db.delete("Credit Wallet", {"team": TEAM})
		for sub in frappe.get_all("Subscription", {"team": TEAM}, pluck="name"):
			frappe.db.delete("Subscription Change", {"subscription": sub})
			frappe.db.delete("Subscription", {"name": sub})

	def _grant(self, amount):
		credits.grant_promotional_credits(TEAM, amount, "INR")

	def _draft(self, total=1000, invoice_type="Billable", period_end="2026-06-30"):
		return (
			frappe.get_doc(
				{
					"doctype": "Invoice",
					"team": TEAM,
					"invoice_type": invoice_type,
					"status": "Draft",
					"period_start": "2026-06-01",
					"period_end": period_end,
					"currency": "INR",
					"subtotal": total,
					"total": total,
					"expected_collection": total,
				}
			)
			.insert(ignore_permissions=True)
			.name
		)

	def _purchase(self):
		"""Run the purchase check a create request passes, returning the rate it reserves."""
		return resource_actions.validate_purchase(TEAM, REGION, self.plan, None, None)[1]

	def _run_server(self, resource_id="res-credit-funded"):
		"""Open billing for a server the region accepted and started."""
		create_subscription(TEAM, REGION, plan=self.plan, resource_id=resource_id).enable()


class TestCreditFundedProvisioning(CreditFundedTestBase):
	def test_credits_create_a_server_without_billing_details(self):
		self._grant(5000)

		self.assertEqual(self._purchase(), RATE)
		# Still no legal name or address on file — and nothing asked for one.
		self.assertFalse(frappe.db.get_value("Billing Profile", TEAM, "legal_name"))

	def test_a_payment_method_is_asked_for_once_credits_fall_short(self):
		self._grant(500)  # a third of the plan's monthly rate

		with self.assertRaises(frappe.ValidationError) as caught:
			self._purchase()

		self.assertEqual(caught.exception.envelope["code"], "PAYMENT_METHOD_REQUIRED")

	def test_no_credits_asks_for_details_as_before(self):
		with self.assertRaises(frappe.ValidationError):
			self._purchase()

	def test_headroom_shrinks_as_credits_fund_running_resources(self):
		self._grant(2000)  # covers one server at 1500, not two

		self._run_server()
		with self.assertRaises(frappe.ValidationError):
			self._purchase()

	def test_pending_requests_count_against_credits(self):
		# A request the region has not answered holds no subscription yet, but its
		# reserved rate is already promised against the same credits.
		self._grant(2000)

		with patch.object(resource_actions, "reserved_rate", return_value=RATE):
			with self.assertRaises(frappe.ValidationError):
				self._purchase()

	def test_a_complete_profile_without_a_payment_method_is_refused(self):
		complete_billing_profile(TEAM)

		with self.assertRaises(frappe.ValidationError):
			self._purchase()

	def test_a_payment_method_needs_no_credits(self):
		complete_billing_profile(TEAM)
		with patch("central.resource_actions.has_active_payment_method", return_value=True):
			self.assertEqual(self._purchase(), RATE)

	@IntegrationTestCase.change_settings("Central Settings", require_payment_method=0)
	def test_a_complete_profile_is_enough_when_the_requirement_is_off(self):
		complete_billing_profile(TEAM)

		self.assertEqual(self._purchase(), RATE)

	def test_an_unpriceable_rate_is_never_treated_as_funded(self):
		self._grant(50000)

		self.assertFalse(settlement.wallet_funds(TEAM, None))


class TestConcurrentFunding(CreditFundedTestBase):
	"""Two creates at once must not both spend the same credit."""

	def _purge_committed(self):
		# The workers commit, so the test rollback cannot undo them.
		frappe.db.delete("Resource Action", {"team": TEAM})
		frappe.db.delete("Credit Ledger Entry", {"team": TEAM})
		frappe.db.delete("Credit Wallet", {"team": TEAM})
		frappe.db.commit()

	def _request(self, index):
		"""The locked part of a create request: check the purchase, then reserve its rate."""
		frappe.db.get_value("Team", TEAM, "name", for_update=True)
		rate = self._purchase()
		ResourceAction.queue(
			"create",
			TEAM,
			REGION,
			f"web-{index}",
			request_key=f"race-{index}-{frappe.generate_hash(length=8)}",
			reserved_monthly_rate=rate,
		)

	def test_only_one_of_four_racing_creates_is_funded(self):
		# Credit for one server at RATE, four callers asking at the same moment.
		self._grant(RATE + 500)
		frappe.db.commit()  # the workers are on their own connections

		try:
			results = run_workers(4, self._request)

			frappe.db.rollback()  # refresh this connection's snapshot
			funded = [r for r in results.values() if r == "ok"]
			self.assertEqual(len(funded), 1, results)
			self.assertEqual(frappe.db.count("Resource Action", {"team": TEAM}), 1)
		finally:
			self._purge_committed()


class TestCreditFundedHeadroom(CreditFundedTestBase):
	def test_headroom_is_the_wallet_under_the_tier_cap(self):
		self._grant(3000)

		self.assertEqual(settlement.credit_funded_headroom(TEAM), 3000)

	def test_the_tier_cap_still_bounds_a_large_wallet(self):
		set_team_tier(TEAM, level="t0", max_spend=1000)
		self._grant(9000)

		self.assertEqual(settlement.credit_funded_headroom(TEAM), 1000)

	def test_no_credits_is_no_headroom_even_under_a_tier(self):
		# Deliberately NOT effective_spend_cap's behaviour: that falls back to the
		# tier cap, which is only safe as a ceiling when a card backs it.
		self.assertEqual(settlement.credit_funded_headroom(TEAM), 0)

	def test_money_movement_stays_strict_however_rich_the_wallet(self):
		from central.billing.api.dashboard._shared import _require_billing_setup

		self._grant(50000)

		with self.assertRaises(frappe.ValidationError):
			_require_billing_setup(TEAM)


class TestInvoiceHeldForBillingDetails(CreditFundedTestBase):
	"""An invoice is held at Draft until we have a legal name to make it out to."""

	def test_a_billable_invoice_is_held_and_the_customer_asked(self):
		self._grant(5000)
		invoice = self._draft()

		result = invoicing.open_and_collect(invoice)

		self.assertEqual(result["held"], "billing_details")
		self.assertEqual(frappe.db.get_value("Invoice", invoice, "status"), "Draft")
		# Credits are untouched: nothing was settled against an invoice never issued.
		self.assertEqual(credits.get_balance(TEAM)["balance"], 5000)
		self.assertTrue(
			frappe.db.exists(
				"Billing Notification Log",
				{"team": TEAM, "event_type": "Billing Details Required", "reference_name": invoice},
			)
		)

	def test_the_held_draft_settles_once_the_details_arrive(self):
		self._grant(5000)
		invoice = self._draft()
		invoicing.open_and_collect(invoice)

		complete_billing_profile(TEAM)
		result = invoicing.open_and_collect(invoice)

		self.assertEqual(result["status"], "Paid")  # covered by the credits in full
		self.assertEqual(frappe.db.get_value("Invoice", invoice, "status"), "Paid")

	def test_a_held_draft_is_not_counted_as_settled(self):
		self._grant(5000)
		invoice = self._draft()

		counters = run.settle_draft_page("2026-07-01", "", "zzzz")

		self.assertEqual(counters["held"], 1)
		self.assertEqual(counters["settled"], 0)
		self.assertEqual(frappe.db.get_value("Invoice", invoice, "status"), "Draft")

	def test_completing_the_profile_settles_what_was_held(self):
		# Otherwise the customer waits for the next monthly run to be billed for
		# credits they have already been provisioned against.
		self._grant(5000)
		invoice = self._draft()
		invoicing.open_and_collect(invoice)

		with patch.object(frappe, "enqueue", run_enqueued_inline):
			complete_billing_profile(TEAM)

		self.assertEqual(frappe.db.get_value("Invoice", invoice, "status"), "Paid")

	def test_any_writer_of_the_profile_releases_the_hold(self):
		# The bench's own billing tab saves through this helper and never touched
		# the dashboard's release path — the hold has to come off the doctype.
		self._grant(5000)
		invoice = self._draft()
		invoicing.open_and_collect(invoice)

		with patch.object(frappe, "enqueue", run_enqueued_inline):
			profile.create_or_update_billing_profile(
				TEAM,
				legal_name="Acme Pvt Ltd",
				address_line1="1 Main Street",
				city="Pune",
				country="India",
			)

		self.assertEqual(frappe.db.get_value("Invoice", invoice, "status"), "Paid")

	def test_a_complete_profile_with_nothing_held_enqueues_nothing(self):
		complete_billing_profile(TEAM)

		with patch.object(frappe, "enqueue") as enqueue:
			frappe.get_doc("Billing Profile", TEAM).save(ignore_permissions=True)

		enqueue.assert_not_called()

	def test_a_cost_report_is_never_held(self):
		# A cost report is a record of what we subsidised, not a bill — there is
		# nobody to make it out to.
		invoice = self._draft(invoice_type="Cost Report")

		result = invoicing.open_and_collect(invoice)

		self.assertTrue(result["cost_report"])
		self.assertEqual(frappe.db.get_value("Invoice", invoice, "status"), "Open")


class TestBillingDetailsEscalation(CreditFundedTestBase):
	"""A bill that waits too long stops being funded and starts paging the operators."""

	def _overdue_draft(self):
		grace = settings.billing_details_grace_days()
		return self._draft(period_end=frappe.utils.add_days(frappe.utils.nowdate(), -grace - 1))

	def test_credit_stops_funding_once_a_bill_has_waited_too_long(self):
		self._grant(5000)
		self.assertEqual(settlement.credit_funded_headroom(TEAM), 5000)

		self._overdue_draft()

		self.assertEqual(settlement.credit_funded_headroom(TEAM), 0)
		with self.assertRaises(frappe.ValidationError):
			self._purchase()

	def test_a_bill_still_inside_the_grace_period_funds_as_before(self):
		self._grant(5000)
		self._draft(period_end=frappe.utils.nowdate())

		self.assertEqual(settlement.credit_funded_headroom(TEAM), 5000)

	def test_a_long_held_invoice_pages_the_operators(self):
		invoice = self._overdue_draft()

		alerts = [a for a in billing_alerts.held_invoices() if a["team"] == TEAM]

		self.assertEqual(len(alerts), 1)
		self.assertEqual(alerts[0]["subject"], invoice)

	def test_a_recent_hold_does_not_page_anybody(self):
		self._draft(period_end=frappe.utils.nowdate())

		self.assertFalse([a for a in billing_alerts.held_invoices() if a["team"] == TEAM])


class TestBillingDetailsReminder(CreditFundedTestBase):
	def _log_count(self):
		return frappe.db.count(
			"Billing Notification Log", {"team": TEAM, "event_type": settlement.BILLING_DETAILS_ASK}
		)

	def test_a_billable_team_without_details_is_asked(self):
		self._grant(5000)
		self._run_server()

		self.assertEqual(settlement.remind_team_page([TEAM]), 1)
		self.assertEqual(self._log_count(), 1)

	def test_a_team_with_details_is_left_alone(self):
		complete_billing_profile(TEAM)
		self._run_server()

		self.assertEqual(settlement.remind_team_page([TEAM]), 0)
		self.assertEqual(self._log_count(), 0)

	def test_a_team_is_not_asked_again_the_next_day(self):
		# The engine only suppresses a repeat for an hour, so a daily sweep would
		# mail every member of the team every day about the same missing field.
		self._grant(5000)
		self._run_server()
		settlement.remind_team_page([TEAM])

		self.assertEqual(settlement.remind_team_page([TEAM]), 0)
		self.assertEqual(self._log_count(), 1)

	def test_a_team_asked_long_enough_ago_is_asked_again(self):
		self._grant(5000)
		self._run_server()
		settlement.remind_team_page([TEAM])
		stale = frappe.utils.add_days(frappe.utils.now_datetime(), -settlement.REMINDER_EVERY_DAYS - 1)
		frappe.db.set_value(
			"Billing Notification Log", {"team": TEAM}, "creation", stale, update_modified=False
		)

		self.assertEqual(settlement.remind_team_page([TEAM]), 1)

	def test_the_sweep_queues_a_team_that_is_running_something(self):
		self._grant(5000)
		self._run_server()

		self.assertIn(TEAM, self._queued_teams())

	def test_the_sweep_skips_a_team_running_nothing(self):
		# Its subscriptions are all disabled: no bill is coming, so there is nothing
		# to ask for. Asking anyway is a nag about an invoice that never arrives.
		self._grant(5000)
		self._run_server()
		frappe.db.set_value("Subscription", {"team": TEAM}, "enabled", 0)

		self.assertNotIn(TEAM, self._queued_teams())

	def _queued_teams(self):
		with patch.object(frappe, "enqueue") as enqueue:
			settlement.run_billing_details_reminder()
		return [team for call in enqueue.call_args_list for team in call.kwargs["teams"]]


class TestPaymentStanding(CreditFundedTestBase):
	"""A team buys more only when it can pay and is not behind on paying."""

	def _invoice(self, status, amount_paid=0):
		name = self._draft()
		frappe.db.set_value("Invoice", name, {"status": status, "amount_paid": amount_paid})
		return name

	def _manual_checkout(self):
		complete_billing_profile(TEAM, currency="INR")
		frappe.db.set_value("Billing Profile", TEAM, "collection_mode", "Manual Checkout")

	def test_an_overdue_invoice_refuses_a_server_even_with_credit(self):
		self._grant(5000)
		self._invoice("Overdue")

		with self.assertRaises(frappe.ValidationError) as caught:
			self._purchase()
		self.assertEqual(caught.exception.envelope["code"], "PAYMENT_OVERDUE")

	def test_a_suspended_subscription_refuses_a_server(self):
		self._grant(5000)
		self._run_server()
		frappe.db.set_value("Subscription", {"team": TEAM}, "account_standing", "Suspended")

		with self.assertRaises(frappe.ValidationError) as caught:
			self._purchase()
		self.assertEqual(caught.exception.envelope["code"], "PAYMENT_OVERDUE")

	def test_manual_checkout_alone_is_not_a_way_to_pay(self):
		self._manual_checkout()

		with self.assertRaises(frappe.ValidationError) as caught:
			self._purchase()
		self.assertEqual(caught.exception.envelope["code"], "PAYMENT_METHOD_REQUIRED")

	def test_manual_checkout_after_a_paid_invoice_is_a_way_to_pay(self):
		self._manual_checkout()
		self._invoice("Paid", amount_paid=1000)

		self.assertEqual(self._purchase(), RATE)

	def test_an_invoice_paid_only_by_credit_does_not_count(self):
		self._manual_checkout()
		self._invoice("Paid", amount_paid=0)

		with self.assertRaises(frappe.ValidationError):
			self._purchase()
