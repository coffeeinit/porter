# Copyright (c) 2026, Frappe and contributors
# For license information, please see license.txt
"""GSTIN status: stored from the GST portal, refreshed in a paced sweep."""

from unittest.mock import patch

import frappe

from central.billing.revenue import gst_status
from central.billing.tests.accounting_fake import requires_accounting_system
from central.billing.tests.utils import BillingTestCase as IntegrationTestCase
from central.billing.tests.utils import complete_billing_profile, ensure_team

GSTIN = "27AAPFU0939F1ZV"
LOOKUP = "central.billing.ingester.customer.get_gstin_details"


def profile_with_gstin(team, status=None, checked_days_ago=None):
	ensure_team(team)
	complete_billing_profile(team)
	checked_at = (
		frappe.utils.add_days(frappe.utils.now_datetime(), -checked_days_ago)
		if checked_days_ago is not None
		else None
	)
	frappe.db.set_value(
		"Billing Profile",
		team,
		{"gstin": GSTIN, "gst_status": status, "gst_status_checked_at": checked_at},
	)
	return team


@requires_accounting_system
class GstStatusTestCase(IntegrationTestCase):
	def setUp(self):
		self._conf = patch.dict(frappe.local.conf, {"enable_erpnext_sync": 1})
		self._conf.start()
		self._pace = patch.object(gst_status, "PACE_SECONDS", 0)
		self._pace.start()
		self._customer_sync = patch("central.billing.ingester.customer._enqueue")
		self._customer_sync.start()

	def tearDown(self):
		self._customer_sync.stop()
		self._pace.stop()
		self._conf.stop()


class TestStore(GstStatusTestCase):
	def test_stores_status_category_and_time(self):
		team = profile_with_gstin("team-gst-store")
		gst_status.store(team, GSTIN, {"status": "cancelled", "gst_category": "SEZ"})
		row = frappe.db.get_value(
			"Billing Profile", team, ["gst_status", "gst_category", "gst_status_checked_at"], as_dict=True
		)
		self.assertEqual(row.gst_status, "Cancelled")
		self.assertEqual(row.gst_category, "SEZ")
		self.assertTrue(row.gst_status_checked_at)

	def test_unknown_status_keeps_the_old_one(self):
		team = profile_with_gstin("team-gst-unknown", status="Active")
		gst_status.store(team, GSTIN, {"status": "Provision"})
		self.assertEqual(frappe.db.get_value("Billing Profile", team, "gst_status"), "Active")

	def test_answer_for_an_old_gstin_is_dropped(self):
		team = profile_with_gstin("team-gst-race", status="Active")
		gst_status.store(team, "29AAPFU0939F1ZV", {"status": "Cancelled"})
		self.assertEqual(frappe.db.get_value("Billing Profile", team, "gst_status"), "Active")


class TestStanding(GstStatusTestCase):
	def test_lapsed_statuses_hide_the_gstin(self):
		for status in gst_status.LAPSED:
			team = profile_with_gstin("team-gst-standing", status=status)
			self.assertEqual(gst_status.standing(team), {"gstin": None, "lapsed": True})

	def test_active_and_unchecked_keep_the_gstin(self):
		for status in ("Active", None):
			team = profile_with_gstin("team-gst-standing", status=status)
			self.assertEqual(gst_status.standing(team), {"gstin": GSTIN, "lapsed": False})


class TestSweep(GstStatusTestCase):
	def test_picks_unchecked_and_stale_oldest_first(self):
		fresh = profile_with_gstin("team-gst-fresh", "Active", checked_days_ago=1)
		stale = profile_with_gstin("team-gst-stale", "Active", checked_days_ago=30)
		never = profile_with_gstin("team-gst-never")
		teams = gst_status.stale_teams(limit=1000)
		self.assertNotIn(fresh, teams)
		self.assertLess(teams.index(never), teams.index(stale))

	def test_respects_the_daily_limit(self):
		for n in range(3):
			profile_with_gstin(f"team-gst-limit-{n}")
		with (
			patch("central.billing.settings.gst_status_daily_limit", return_value=2),
			patch(LOOKUP, return_value={"status": "Active"}) as lookup,
		):
			gst_status.refresh_stale()
		self.assertEqual(lookup.call_count, 2)

	def test_stops_after_failures_in_a_row(self):
		for n in range(gst_status.MAX_FAILURES_IN_A_ROW + 3):
			profile_with_gstin(f"team-gst-down-{n}")
		with patch(LOOKUP, side_effect=ConnectionError("portal down")) as lookup:
			result = gst_status.refresh_stale()
		self.assertEqual(lookup.call_count, gst_status.MAX_FAILURES_IN_A_ROW)
		self.assertEqual(result["failed"], gst_status.MAX_FAILURES_IN_A_ROW)

	def test_failed_teams_step_aside_for_the_rest(self):
		teams = [
			profile_with_gstin(f"team-gst-flaky-{n}") for n in range(gst_status.MAX_FAILURES_IN_A_ROW + 2)
		]
		real = gst_status.stale_teams

		def only_ours(limit):
			# Other profiles on the site must not take the failing slots.
			return [t for t in real(limit) if t in teams]

		with patch.object(gst_status, "stale_teams", side_effect=only_ours):
			with patch(LOOKUP, side_effect=ConnectionError("portal down")):
				gst_status.refresh_stale()
			with patch(LOOKUP, return_value={"status": "Active"}):
				gst_status.refresh_stale()
		rows = frappe.get_all(
			"Billing Profile",
			filters={"name": ["in", teams]},
			fields=["gst_status_checked_at", "gst_status_retry_after"],
		)
		deferred = [r for r in rows if r.gst_status_retry_after and not r.gst_status_checked_at]
		reached = [r for r in rows if r.gst_status_checked_at]
		self.assertEqual(len(deferred), gst_status.MAX_FAILURES_IN_A_ROW)
		self.assertEqual(len(reached), 2)

	def test_failure_after_the_status_is_stored_undoes_it(self):
		team = profile_with_gstin("team-gst-half", "Active", checked_days_ago=30)
		before = frappe.db.get_value("Billing Profile", team, "gst_status_checked_at")
		real = gst_status.stale_teams
		with (
			patch.object(
				gst_status, "stale_teams", side_effect=lambda limit: [t for t in real(limit) if t == team]
			),
			patch(LOOKUP, return_value={"status": "Cancelled", "gst_category": "SEZ"}),
			patch(
				"central.billing.payments.provisioning.apply_gst_category", side_effect=RuntimeError("boom")
			),
		):
			self.assertEqual(gst_status.refresh_stale()["failed"], 1)
		row = frappe.db.get_value(
			"Billing Profile",
			team,
			["gst_status", "gst_category", "gst_status_checked_at", "gst_status_retry_after"],
			as_dict=True,
		)
		self.assertEqual(row.gst_status, "Active")  # the half-stored answer is gone
		self.assertFalse(row.gst_category)
		self.assertEqual(row.gst_status_checked_at, before)  # still stale, so it is retried
		self.assertTrue(row.gst_status_retry_after)  # ... after its wait

	def test_sweep_leaves_the_commit_to_its_job(self):
		profile_with_gstin("team-gst-nocommit")
		with (
			patch(LOOKUP, return_value={"status": "Active"}),
			patch.object(frappe.db, "commit") as commit,
		):
			gst_status.refresh_stale()
		commit.assert_not_called()

	def test_does_nothing_when_lookups_are_off(self):
		profile_with_gstin("team-gst-off")
		frappe.local.conf["enable_erpnext_sync"] = 0
		with patch(LOOKUP) as lookup:
			self.assertEqual(gst_status.refresh_stale()["skipped"], "lookups_off")
		lookup.assert_not_called()


class TestRecheck(GstStatusTestCase):
	def test_recent_check_is_answered_from_the_store(self):
		team = profile_with_gstin("team-gst-recheck", "Cancelled", checked_days_ago=0)
		with patch("central.billing.revenue.gst_status._enqueue_refresh") as enqueue:
			self.assertFalse(gst_status.recheck(team))
		enqueue.assert_not_called()

	def test_old_check_is_queued_not_asked_in_the_request(self):
		team = profile_with_gstin("team-gst-recheck", "Cancelled", checked_days_ago=1)
		with patch("central.billing.revenue.gst_status._enqueue_refresh") as enqueue, patch(LOOKUP) as lookup:
			self.assertTrue(gst_status.recheck(team))
		enqueue.assert_called_once_with(team)
		lookup.assert_not_called()  # the portal is asked by the job, not the request

	def test_no_gstin_nothing_to_check(self):
		team = profile_with_gstin("team-gst-recheck", "Cancelled", checked_days_ago=1)
		frappe.db.set_value("Billing Profile", team, "gstin", None)
		with patch("central.billing.revenue.gst_status._enqueue_refresh") as enqueue:
			self.assertFalse(gst_status.recheck(team))
		enqueue.assert_not_called()


class TestGstinChange(GstStatusTestCase):
	def test_new_gstin_forgets_the_old_status(self):
		team = profile_with_gstin("team-gst-change", "Cancelled", checked_days_ago=1)
		doc = frappe.get_doc("Billing Profile", team)
		doc.gstin = "27AAACR5055K1Z7"
		with patch("frappe.enqueue") as enqueue:
			doc.save(ignore_permissions=True)
		row = frappe.db.get_value(
			"Billing Profile", team, ["gst_status", "gst_status_checked_at"], as_dict=True
		)
		self.assertFalse(row.gst_status)
		self.assertFalse(row.gst_status_checked_at)
		methods = [c.args[0] for c in enqueue.call_args_list]
		self.assertIn("central.billing.revenue.gst_status.refresh", methods)


class TestSezFollowsTheGstin(GstStatusTestCase):
	def _sez(self, team):
		profile_with_gstin(team, "Active", checked_days_ago=1)
		from central.billing.payments.provisioning import apply_gst_category

		apply_gst_category(team, "SEZ")

	def _zero_rated(self, team):
		return frappe.db.get_value("Tax Profile", team, "zero_rated")

	def test_removed_gstin_drops_sez(self):
		self._sez("team-gst-sez-removed")
		frappe.local.conf["enable_erpnext_sync"] = 0  # cleared even without lookups
		doc = frappe.get_doc("Billing Profile", "team-gst-sez-removed")
		doc.gstin = None
		doc.save(ignore_permissions=True)
		self.assertEqual(self._zero_rated("team-gst-sez-removed"), 0)

	def test_changed_gstin_drops_sez_without_lookups(self):
		self._sez("team-gst-sez-unchecked")
		frappe.local.conf["enable_erpnext_sync"] = 0
		doc = frappe.get_doc("Billing Profile", "team-gst-sez-unchecked")
		doc.gstin = "27AAACR5055K1Z7"
		doc.save(ignore_permissions=True)
		self.assertEqual(self._zero_rated("team-gst-sez-unchecked"), 0)

	def test_changed_gstin_drops_sez_until_its_lookup(self):
		self._sez("team-gst-sez-changed")
		doc = frappe.get_doc("Billing Profile", "team-gst-sez-changed")
		doc.gstin = "27AAACR5055K1Z7"
		with patch("frappe.enqueue"):
			doc.save(ignore_permissions=True)
		self.assertEqual(self._zero_rated("team-gst-sez-changed"), 0)
		gst_status.store("team-gst-sez-changed", doc.gstin, {"status": "Active", "gst_category": "SEZ"})
		self.assertEqual(self._zero_rated("team-gst-sez-changed"), 1)


class TestLapseReachesTheCustomer(GstStatusTestCase):
	def test_a_status_flip_queues_a_customer_sync(self):
		team = profile_with_gstin("team-gst-flip", "Active", checked_days_ago=1)
		with patch("central.billing.ingester.customer.enqueue_for") as enqueue:
			gst_status.store(team, GSTIN, {"status": "Active"})
			enqueue.assert_not_called()
			gst_status.store(team, GSTIN, {"status": "Cancelled"})
			enqueue.assert_called_once_with(team)
