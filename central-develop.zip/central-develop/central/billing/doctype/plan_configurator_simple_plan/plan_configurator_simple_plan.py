# Copyright (c) 2026, Frappe and contributors
# For license information, please see license.txt

from frappe.model.document import Document


class PlanConfiguratorSimplePlan(Document):
	# begin: auto-generated types
	# This code is auto-generated. Do not modify anything in this block.

	from typing import TYPE_CHECKING

	if TYPE_CHECKING:
		from frappe.types import DF

		multiplier: DF.Float
		parent: DF.Data
		parentfield: DF.Data
		parenttype: DF.Data
		plan: DF.Link | None
		quantity: DF.Float
		resource_type: DF.Link
		title: DF.Data
		unit: DF.Data
	# end: auto-generated types

	pass
