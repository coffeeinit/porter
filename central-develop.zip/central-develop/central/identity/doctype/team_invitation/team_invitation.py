# Copyright (c) 2026, frappe and contributors
# For license information, please see license.txt

import frappe
from frappe import _
from frappe.model.document import Document
from frappe.utils import (
	add_days,
	add_to_date,
	cint,
	get_datetime,
	get_fullname,
	getdate,
	now,
	today,
	validate_email_address,
)

from central.iam import can, user_has_operator_bypass
from central.identity.doctype.team_member.team_member import validate_resource_scope
from central.sso import central_url

DEFAULT_EXPIRY_DAYS = 14


class TeamInvitation(Document):
	# begin: auto-generated types
	# This code is auto-generated. Do not modify anything in this block.

	from typing import TYPE_CHECKING

	if TYPE_CHECKING:
		from frappe.types import DF

		accepted_at: DF.Datetime | None
		accepted_by: DF.Link | None
		email: DF.Data
		expires_on: DF.Date | None
		invited_by: DF.Link | None
		resource_name: DF.Data | None
		resource_type: DF.Literal["*", "Server", "Site"]
		role: DF.Link
		status: DF.Literal["Pending", "Accepted", "Expired", "Revoked", "Declined"]
		team: DF.Link
		token: DF.Data | None
	# end: auto-generated types

	def before_insert(self) -> None:
		self.email = self.email.strip().lower()
		self.status = "Pending"
		self.invited_by = frappe.session.user
		self.token = frappe.generate_hash(length=32)
		self.resource_type = self.resource_type or "*"
		if self.resource_type == "*":
			self.resource_name = None
		self.expires_on = get_expiry_date()
		self.accepted_by = None
		self.accepted_at = None

	def validate(self) -> None:
		validate_email_address(self.email, throw=True)
		if self.is_new():
			self._require_manager()
			self._validate_send_rate()
		self._validate_role()
		self._validate_resource()
		self._validate_user()
		self._validate_duplicate()
		self._validate_update()

	def after_insert(self) -> None:
		self.send_email()

	def send_email(self) -> None:
		# Not a notification: the invitee is not a team member yet.
		team_name = frappe.db.get_value("Team", self.team, "team_name")
		invited_by = get_fullname(self.invited_by)
		frappe.sendmail(
			recipients=[self.email],
			subject=_("{0} invited you to join {1} on Frappe Cloud").format(invited_by, team_name),
			template="team_invitation",
			args={
				"team_name": team_name,
				"invited_by": invited_by,
				"role": self.role_name,
				"expires_on": frappe.format(self.expires_on, "Date"),
				"invitation_url": f"{central_url()}/dashboard/join/{self.token}",
			},
			reference_doctype=self.doctype,
			reference_name=self.name,
		)

	def get_summary(self) -> dict:
		"""What the join page shows."""
		return {
			"name": self.name,
			"email": self.email,
			"status": "Expired" if self.status == "Pending" and self._is_expired() else self.status,
			"team_name": frappe.db.get_value("Team", self.team, "team_name"),
			"invited_by": get_fullname(self.invited_by),
			"role": self.role_name,
			"expires_on": self.expires_on,
			"has_account": bool(frappe.db.exists("User", self.email)),
		}

	# Internal; the HTTP surface is central.api.teams.accept_invitation.
	def accept(self) -> dict:
		user = frappe.session.user
		if self.status == "Accepted" and self.accepted_by == user:
			return {"team": self.team, "role": self.role, "accepted": False}
		if self.email != user:
			frappe.throw(
				_(
					"This invitation was sent to a different email address. Sign in with the invited email to continue."
				),
				frappe.PermissionError,
			)
		if self.status != "Pending":
			frappe.throw(
				_(
					"This invitation has already been answered or revoked. Ask a team admin for a new invitation if you still need access."
				)
			)
		if self._is_expired():
			frappe.throw(_("This invitation has expired. Ask a team admin to resend it."))

		team = frappe.get_doc("Team", self.team)
		team.add_member_from_invitation(
			user,
			self.role,
			resource_type=self.resource_type or "*",
			resource_name=self.resource_name,
		)

		self.status = "Accepted"
		self.accepted_by = user
		self.accepted_at = now()
		self.flags.from_invitation_action = True
		self.save()

		return {"team": self.team, "role": self.role, "accepted": True}

	# Internal; the HTTP surface is central.api.teams.revoke_invitation.
	def revoke(self) -> bool:
		self._require_manager()
		if self.status == "Revoked":
			return False
		if self.status != "Pending":
			frappe.throw(_("Only a pending invitation can be revoked."))
		self.status = "Revoked"
		self.flags.from_invitation_action = True
		self.save()

		return True

	# Internal; the HTTP surface is central.api.teams.resend_invitation.
	def resend(self) -> dict:
		self._require_manager()
		if self.status != "Pending":
			frappe.throw(_("Only a pending invitation can be resent."))
		cooldown = cint(
			frappe.get_cached_value(
				"Central Settings", "Central Settings", "invitation_resend_cooldown_minutes"
			)
		)
		if not user_has_operator_bypass() and get_datetime(self.modified) > add_to_date(
			None, minutes=-cooldown
		):
			frappe.throw(
				_("This invitation was sent less than {0} minutes ago. Try again later.").format(cooldown)
			)

		# A new token also cancels the link in the earlier email.
		self.token = frappe.generate_hash(length=32)
		self.expires_on = get_expiry_date()
		self.flags.from_invitation_action = True
		self.save()
		self.send_email()

		return {"name": self.name, "expires_on": self.expires_on}

	# Internal; the HTTP surface is central.api.teams.decline_invitation.
	def decline(self) -> bool:
		if self.email != frappe.session.user and not user_has_operator_bypass():
			frappe.throw(
				_(
					"This invitation was sent to a different email address. Sign in with the invited email to continue."
				),
				frappe.PermissionError,
			)
		if self.status != "Pending":
			frappe.throw(_("Only a pending invitation can be declined."))

		self.status = "Declined"
		self.flags.from_invitation_action = True
		self.save()

		return True

	def _validate_send_rate(self) -> None:
		if user_has_operator_bypass():
			return

		sent = frappe.db.count(
			"Team Invitation",
			{"invited_by": frappe.session.user, "creation": (">", add_to_date(None, hours=-1))},
		)
		# Invitations are platform-branded mail to any address, so one person cannot send without limit.
		if sent >= cint(
			frappe.get_cached_value("Central Settings", "Central Settings", "invitations_per_hour")
		):
			frappe.throw(_("You have sent too many invitations. Try again in an hour."))

	def _validate_role(self) -> None:
		if self.role == "Owner":
			frappe.throw(_("Owner cannot be assigned through an invitation."))

		role_team, is_system = frappe.db.get_value("Team Role", self.role, ["team", "is_system"]) or (None, 0)
		if not is_system and role_team != self.team:
			frappe.throw(_("Team Role {0} does not belong to this team.").format(self.role))

	def _validate_resource(self) -> None:
		validate_resource_scope(self, self.team)

	def _validate_user(self) -> None:
		if not self.is_new():
			return

		enabled = frappe.db.get_value("User", self.email, "enabled")
		if enabled == 0:
			frappe.throw(_("Disabled users cannot be invited."))
		if frappe.db.exists("Team Member", {"parent": self.team, "user": self.email}):
			frappe.throw(_("This user is already a team member."))

	def _validate_duplicate(self) -> None:
		if not self.is_new():
			return

		existing = frappe.db.exists(
			"Team Invitation",
			{"team": self.team, "email": self.email, "status": "Pending"},
		)
		if existing:
			frappe.throw(
				_(
					"This person already has a pending invitation. Resend it from the Invitations list instead of creating another."
				)
			)

	def _validate_update(self) -> None:
		if self.is_new() or self.flags.from_invitation_action or user_has_operator_bypass():
			return

		previous = self.get_doc_before_save()
		if not previous:
			return

		fields = (
			"team",
			"email",
			"role",
			"resource_type",
			"resource_name",
			"status",
			"invited_by",
			"expires_on",
			"accepted_by",
			"accepted_at",
			"token",
		)
		if any(self.get(field) != previous.get(field) for field in fields):
			frappe.throw(_("Use the invitation actions to change its status."), frappe.PermissionError)

	def _require_manager(self) -> None:
		if not user_has_operator_bypass() and not can(frappe.session.user, self.team, "team:manage_members"):
			frappe.throw(_("Not permitted to manage members for this team."), frappe.PermissionError)

	@property
	def role_name(self) -> str:
		return frappe.db.get_value("Team Role", self.role, "role_name") or self.role

	@property
	def is_pending(self) -> bool:
		return self.status == "Pending" and not self._is_expired()

	def _is_expired(self) -> bool:
		return bool(self.expires_on and getdate(self.expires_on) < getdate(today()))


def get_expiry_date() -> str:
	return add_days(today(), get_expiry_days())


def get_expiry_days() -> int:
	"""How many days a new invitation stays open."""
	# A site saved before the setting existed reads it as empty.
	days = frappe.get_cached_value("Central Settings", "Central Settings", "invitation_expiry_days")
	return days or DEFAULT_EXPIRY_DAYS


def get_invitation_by_token(token: str) -> TeamInvitation:
	name = frappe.db.get_value("Team Invitation", {"token": token}) if token else None
	if not name:
		frappe.throw(
			_(
				"This invitation link is not valid. Open the link in your latest invitation email, or ask a team admin to send a new invitation."
			),
			frappe.DoesNotExistError,
		)

	return frappe.get_doc("Team Invitation", name)


def on_doctype_update() -> None:
	frappe.db.add_unique("Team Invitation", ["token"])


def expire_pending_invitations() -> None:
	for name in frappe.get_all(
		"Team Invitation",
		filters={"status": "Pending", "expires_on": ["<", today()]},
		pluck="name",
	):
		invitation = frappe.get_doc("Team Invitation", name)
		invitation.status = "Expired"
		invitation.save()
