---
name: Cloud Infrastructure Control Plane
colors:
  surface: '#f9f9ff'
  surface-dim: '#d3dae9'
  surface-bright: '#f9f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff3ff'
  surface-container: '#e7eefd'
  surface-container-high: '#e2e8f7'
  surface-container-highest: '#dce3f2'
  on-surface: '#151c27'
  on-surface-variant: '#424655'
  inverse-surface: '#2a313c'
  inverse-on-surface: '#ebf1ff'
  outline: '#727786'
  outline-variant: '#c2c6d7'
  surface-tint: '#0058cb'
  primary: '#0056c8'
  on-primary: '#ffffff'
  primary-container: '#146ef5'
  on-primary-container: '#fffdff'
  inverse-primary: '#b0c6ff'
  secondary: '#5d5e63'
  on-secondary: '#ffffff'
  secondary-container: '#e2e2e8'
  on-secondary-container: '#636469'
  tertiary: '#006b43'
  on-tertiary: '#ffffff'
  tertiary-container: '#008755'
  on-tertiary-container: '#fefffa'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d9e2ff'
  primary-fixed-dim: '#b0c6ff'
  on-primary-fixed: '#001945'
  on-primary-fixed-variant: '#00429c'
  secondary-fixed: '#e2e2e8'
  secondary-fixed-dim: '#c6c6cb'
  on-secondary-fixed: '#1a1c20'
  on-secondary-fixed-variant: '#45474b'
  tertiary-fixed: '#7dfab7'
  tertiary-fixed-dim: '#5fdd9d'
  on-tertiary-fixed: '#002111'
  on-tertiary-fixed-variant: '#005232'
  background: '#f9f9ff'
  on-background: '#151c27'
  surface-variant: '#dce3f2'
typography:
  display-xl:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: -0.01em
  body-base:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: -0.005em
  body-base-medium:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: -0.005em
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0em
  body-sm-medium:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: 0em
  caption-xs:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
  code-base:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: -0.01em
  code-sm:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  margin: 1.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
---

## Brand & Style

This design system expresses high-reliability infrastructure management with the precision and restraint found in top-tier operating systems and modern developer platforms. Designed for engineers orchestrating declarative MicroVMs, the visual language balances surgical utility with refined tactile polish. 

### Visual Archetype & Movement
The design language combines **Modern Utilitarian Minimalism** with **Apple-inspired industrial restraint**:
- **Purity of Surface:** Deeply disciplined contrast tiers between neutral canvases, floating white working panels, and microscopic 1px structural hairlines.
- **Engineered Legibility:** Content-forward layout where telemetry, machine states, commit digests, and IP configurations take absolute visual priority over superfluous decorative elements.
- **Quiet Confidence:** Purposeful color allocation. Vibrant signaling (electric blue, emerald, amber, crimson) is strictly reserved for user-directed focus, active deployments, and operational telemetry.
- **Developer Affordances:** Dense tabular datasets, monospaced computational fragments, keyboard-first navigation shortcuts (`⌘K`), and deterministic step pipelines designed for rapid scanning under operational pressure.

## Colors

The color palette prioritizes high-fidelity legibility, subtle tonal separation, and clear diagnostic status indication across light interfaces with specialized dark accents (such as terminal consoles, code inspectors, and command surfaces).

### Semantic Roles & Palette Application
- **Canvas Base (`#f8f9fb`):** The persistent app backdrop across the control plane canvas.
- **Surface Elevation 0 (`#ffffff`):** Foreground panels, modular card wrappers, high-density data tables, active sidebars, and floating command palettes.
- **Structural Hairlines (`#e4e7ec`):** Crisp 1px borders enforcing layout boundaries, cell dividers, column delineations, and component splits.
- **Primary Ink / High-Contrast Slate (`#17191d`):** Primary headings, numerical metric totals, table identifiers, and interactive states.
- **Secondary Ink / Muted Slate (`#69707d`):** Labels, breadcrumb parents, meta attributes, timestamps, and column header keys.
- **Brand Interactive Blue (`#146ef5` / `#0071e3`):** Action targets, progress indicators, selected states, focal ring highlights, and commit references.
- **Telemetry Emerald (`#13a66b`):** Online MicroVM states, healthy deployment steps, operational clusters, and active routing.
- **Telemetry Amber (`#c97900`):** Provisioning phases, memory pressure warnings, non-blocking step rollbacks, and DNS propagation waits.
- **Telemetry Crimson (`#d83c4a`):** Kernel panics, fatal build steps, network disconnects, and destructive teardowns.

## Typography

The type hierarchy anchors on technical precision and scanability. It relies on a neutral system-grade grotesque sans-serif (`Inter`, backed by native Apple `-apple-system, BlinkMacSystemFont, "SF Pro Text"`) paired with an uncompromising developer monospace (`JetBrains Mono`).

### Application Guidelines
- **Proportional Sans (`Inter`):** Drives structural UI elements, contextual summaries, table headings, controls, interactive modal actions, and meta text.
- **Monospace (`JetBrains Mono`):** Applied strictly to computational variables: SHA-256 commit hashes, VM IDs (`vm_01hk...`), IP CIDR blocks, port mappings, resource memory specs (`512MB / 1 vCPU`), and raw CLI command traces.
- **Tabular Figures:** All numerical tables, live latency indicators, and CPU utilization counters must enforce `font-feature-settings: "tnum" 1` to eliminate layout jitter during high-frequency real-time updates.

## Layout & Spacing

The control plane implements a strict **Fixed-Sidebar & Fluid Content Structure** tailored for information-dense workspace productivity.

```
+-------------------------------------------------------------------------+
| [256px Fixed Sidebar]  |  [Persistent Topbar: Breadcrumbs + ⌘K Search]  |
|                        |------------------------------------------------|
|                        |  [Canvas Viewport / Density Grids / Stepper]   |
|                        |                                                |
+-------------------------------------------------------------------------+
```

### Architectural Layout Units
- **Standardized Sticky Sidebar:** Width strictly fixed at `256px`. Anchored full height `100vh`, locking project selection, environment contexts, and primary subsystem links.
- **Persistent Global Topbar:** Height pinned to `48px` or `56px`. Housing hierarchical breadcrumbs, region indicators, universal `⌘K` global search palette trigger, and deployment notification center.
- **Data Workspaces:** Maximum canvas width is unbounded (`fluid`), guarded with a minimum width requirement of `1024px` for table integrity, using `1.5rem` outer horizontal padding.

### Grid Rhythm & Adapting Views
- **Desktop (>1280px):** Sidebar is permanently pinned. Dynamic 12-column layout handles multi-metric charts and split view code/configuration diffs.
- **Tablet (768px - 1279px):** Primary sidebar collapses into a narrow icon-rail (`64px`) or an off-canvas drawer. Data grids enable native horizontal panning with frozen primary keys (e.g. Instance Name/ID).
- **Mobile (<767px):** Single-column stack. Sticky navigation drawer with bottom action bar. Non-essential table columns hide behind expandable row drawers.

## Elevation & Depth

Visual hierarchy is maintained predominantly through **tonal separation and razor-sharp 1px boundary lines (`#e4e7ec`)** rather than aggressive multi-layered drop shadows. Shadows are applied only to indicate transient layer changes (flyouts, modal drawers, and search palettes).

### Elevation Layers
- **Level 0 (Flat Ground):** `#f8f9fb` canvas backdrop. No borders or shadows.
- **Level 1 (Card & Panel Tier):** `#ffffff` surfaces bordered with crisp `1px solid #e4e7ec`. Completely flat (`box-shadow: none`), preserving structural industrial clarity.
- **Level 2 (Interactive Floating / Hover):** `#ffffff` surfaces lifted with subtle ambient diffusion: `0 1px 3px rgba(0, 0, 0, 0.04), 0 4px 8px rgba(0, 0, 0, 0.02)` and border `#d8dce2`.
- **Level 3 (Overlays & Command Center):** Applied to the `⌘K` Quicksearch palette and deployment log flyouts. Background `#ffffff` (or dark terminal backdrop `#121316`), elevated by `0 16px 32px -4px rgba(0, 0, 0, 0.08), 0 4px 12px -2px rgba(0, 0, 0, 0.04)`, bordered by `1px solid #d0d5dd`.

## Shapes

The design system implements a refined, low-curvature geometric profile (`roundedness: 1`), providing an engineered appearance that remains soft and friendly without falling into bubbly consumer aesthetic patterns.

### Radius Assignments
- **Base Components (`0.25rem` / 4px):** Form inputs, buttons, tabular tag pills, dropdown items, tooltips, and live status badges.
- **Containers & Surfaces (`0.5rem` / 8px - `rounded-lg`):** Data cards, modular dashboard blocks, command palette wrappers, code panels, and slide-over drawers.
- **Full Radius (`9999px`):** Status indicator dots, user presence indicators, and numeric notification counts.

## Components

### Buttons
- **Primary:** Background `#146ef5`, color `#ffffff`, subtle inset top highlight (`box-shadow: inset 0 1px 0 rgba(255,255,255,0.18)`), hover `#005bda`, active `#004bb5`. Border radius `4px`, font size `13px`, font weight `500`.
- **Secondary / Neutral:** Background `#ffffff`, border `1px solid #e4e7ec`, color `#17191d`, hover background `#f8f9fb`, hover border `#d0d5dd`.
- **Destructive:** Background `#ffffff`, border `1px solid #fecdca`, text `#d83c4a`, hover background `#fef3f2`.
- **Ghost:** Transparent background, text `#69707d`, hover background `#f2f4f7`, hover text `#17191d`.

### Live Status Pills
- Micro status badges designed for instant health recognition:
  - **Healthy / Running:** Pill container `#ecfdf3`, border `1px solid #a6f4c5`, text `#13a66b`. Includes a pulsing `6px` emerald circle dot.
  - **Provisioning / Pending:** Pill container `#fffbeb`, border `1px solid #fedf89`, text `#c97900`.
  - **Terminated / Failed:** Pill container `#fef3f2`, border `1px solid #fecdca`, text `#d83c4a`.

### High-Density Data Tables
- Outer frame wrapped in `#ffffff` with `1px solid #e4e7ec` and `8px` corner radius.
- **Header Row:** Height `36px`, background `#f8f9fb`, border bottom `1px solid #e4e7ec`, text `#69707d`, font size `11px`, font weight `600`, uppercase letter spacing `0.05em`.
- **Data Rows:** Height `44px`, background `#ffffff`, border bottom `1px solid #f2f4f7`, alternating row hover `#fcfcfd`. Inline monospace badges for addresses and commit tags. Action menus (`...`) appear on row hover.

### 7-Step Deployment Stepper
A persistent visual progress bar tracking the lifecycle of declarative MicroVMs:
1. `Specification Parsed`
2. `RootFS Image Built`
3. `Kernel Attached`
4. `Firecracker MicroVM Spun`
5. `TAP Device Configured`
6. `Health Check Probed`
7. `Traffic Shifted`
- **In-Progress Step:** Electric blue spinner icon, label in bold slate `#17191d`, with animated blue indicator line.
- **Complete Step:** Emerald check badge, connecting line in solid emerald `#13a66b`.
- **Pending Step:** Muted numeric pill in `#e4e7ec`, label in `#69707d`.

### Command Palette (`⌘K`)
Modal overlay backdrop `rgba(23, 25, 29, 0.4)` with `backdrop-filter: blur(4px)`. Centered container width `640px`, background `#ffffff`, border `1px solid #e4e7ec`, shadow level 3. Features an instantaneous input bar, monospace keyboard shortcut chips (`ESC`, `↑`, `↓`, `↵`), and grouped results categorized into *Machines*, *Deployments*, *Virtual Networks*, and *Actions*.

### Input Fields & Controls
- **Inputs:** Height `36px`, surface `#ffffff`, border `1px solid #e4e7ec`, typography `13px Inter`. Focus state triggers border `#146ef5` with `0 0 0 3px rgba(20, 110, 245, 0.12)`.
- **Monospace Input Variants:** Used for environment variables, key-value configurations, and startup shell parameters with `JetBrains Mono`.