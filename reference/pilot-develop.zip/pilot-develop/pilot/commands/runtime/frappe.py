from __future__ import annotations

import subprocess
import sys
from dataclasses import dataclass
from typing import ClassVar

from pilot.commands import Command
from pilot.exceptions import BenchError


@dataclass(kw_only=True)
class FrappeCommand(Command):
    name: ClassVar[str] = "frappe"
    help: ClassVar[str] = (
        "Run a Frappe CLI command, without a '--' separator. "
        "Example: pilot -b NAME frappe --site SITE migrate. "
        "Add --help after a Frappe command to see its options."
    )

    args: tuple[str, ...] = ()

    def run(self) -> None:
        if "drop-site" in self.args:
            # Frappe's drop-site leaves the site in nginx, its domains and the backup schedule.
            from pilot.commands.sites.drop import DropSiteCommand

            DropSiteCommand.from_frappe_args(self.bench, self.args).run()
            return
        python = self.bench.env_path / "bin" / "python"
        if not python.exists():
            raise BenchError("Frappe environment not found. Run 'pilot init' first.")
        result = subprocess.run(
            [*self.bench.frappe_call, "frappe", *self.args],
            cwd=self.bench.sites_path,
        )
        sys.exit(result.returncode)
