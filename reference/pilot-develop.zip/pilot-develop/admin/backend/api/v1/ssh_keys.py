from __future__ import annotations

from pathlib import Path
from typing import TypedDict

from flask import Blueprint, current_app, jsonify, request

from admin.backend.api.responses import created_response, error_response, no_content_response
from pilot.core.bench import Bench
from pilot.core.server import (
    InvalidSSHKeyError,
    LastSSHKeyError,
    Server,
    SSHKey,
    SSHKeyAlreadyExistsError,
    SSHKeyNotFoundError,
)


class AuthorizedSSHKey(TypedDict):
    fingerprint: str
    type: str
    comment: str


class AuthorizedSSHKeys(TypedDict):
    keys: list[AuthorizedSSHKey]


ssh_keys_bp = Blueprint("ssh_keys", __name__)


def _current_bench() -> Bench:
    return Bench(Path(current_app.config["BENCH_ROOT"]))


def _serialize(key: SSHKey) -> dict:
    return {"fingerprint": key.fingerprint, "type": key.key_type, "comment": key.comment}


@ssh_keys_bp.get("")
def list_keys():
    return jsonify({"keys": [_serialize(key) for key in Server().ssh_keys.list()]})


@ssh_keys_bp.post("")
def add_key():
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        return error_response("malformed_request", "Expected a JSON object.", 400)
    public_key = data.get("public_key", "")
    if not isinstance(public_key, str):
        return error_response("invalid_ssh_key", "Public key must be a string.", 422)
    public_key = public_key.strip()
    if not public_key:
        return error_response("invalid_ssh_key", "A public key is required.", 422)
    try:
        key = Server().ssh_keys.add(public_key)
    except SSHKeyAlreadyExistsError:
        return error_response("ssh_key_already_exists", "That key is already authorized.", 409)
    except InvalidSSHKeyError as error:
        return error_response("invalid_ssh_key", str(error), 422)
    _current_bench().audit_action("ssh_key", {"event": "added", "fingerprint": key.fingerprint})
    return created_response(_serialize(key), f"/api/v1/ssh-keys/{key.fingerprint}")


@ssh_keys_bp.delete("/<fingerprint>")
def remove_key(fingerprint: str):
    try:
        Server().ssh_keys.remove(fingerprint)
    except SSHKeyNotFoundError:
        return error_response("ssh_key_not_found", "SSH key was not found.", 404)
    except LastSSHKeyError as error:
        return error_response("ssh_key_removal_rejected", str(error), 409)
    _current_bench().audit_action("ssh_key", {"event": "removed", "fingerprint": fingerprint})
    return no_content_response()
