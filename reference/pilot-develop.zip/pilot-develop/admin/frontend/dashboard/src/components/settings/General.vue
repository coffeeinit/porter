<script setup lang="ts">
import { ErrorMessage, Spinner, Switch, toast } from 'frappe-ui'
import { onMounted, ref } from 'vue'
import { settingsApi } from '@/api/settings'
import Git from '@/components/settings/Git.vue'
import LLM from '@/components/settings/LLM.vue'
import Mail from '@/components/settings/Mail.vue'
import Notifications from '@/components/settings/Notifications.vue'
import S3Bucket from '@/components/settings/S3Bucket.vue'
import SettingsRow from '@/components/settings/SettingsRow.vue'
import { GENERAL_SECTIONS } from '@/components/settings/sections'
import Version from '@/components/settings/Version.vue'
import Workers from '@/components/settings/Workers.vue'
import { useSession } from '@/composables/auth/useSession'
import { errorMessage } from '@/utils/error'

const openSection = defineModel<{ id: string } | null>('openSection')
const sections = GENERAL_SECTIONS.filter((section) => !section.parent)

const { session } = useSession()

const loading = ref(true)
const saving = ref(false)
const error = ref('')
const allowDeveloperMode = ref(false)
const liteMode = ref(false)
const liteModeSupported = ref(false)

const toggleAllowDeveloperMode = async (value: boolean) => {
  saving.value = true
  error.value = ''
  try {
    await settingsApi.update({ bench: { allow_developer_mode: value } })
    allowDeveloperMode.value = value
    session.developerMode = value
    toast.success(`Developer mode ${value ? 'allowed' : 'disallowed'}`)
  } catch (e) {
    error.value = errorMessage(e, 'Could not update developer mode setting.')
  } finally {
    saving.value = false
  }
}

const toggleLiteMode = async (value: boolean) => {
  saving.value = true
  error.value = ''
  try {
    await settingsApi.update({ lite_mode: { enabled: value } })
    liteMode.value = value
    toast.success(`Lite mode ${value ? 'enabled' : 'disabled'}. Rebuilding the process set.`)
  } catch (e) {
    error.value = errorMessage(e, 'Could not update lite mode setting.')
  } finally {
    saving.value = false
  }
}

onMounted(async () => {
  try {
    const data = await settingsApi.get()
    allowDeveloperMode.value = Boolean(data?.bench?.allow_developer_mode)
    liteMode.value = Boolean(data?.lite_mode?.enabled)
    liteModeSupported.value = Boolean(data?.lite_mode?.supported)
  } catch {
    error.value = 'Could not load settings.'
  } finally {
    loading.value = false
  }
})
</script>

<template>
  <div v-if="loading" class="flex justify-center items-center h-40">
    <Spinner size="lg" class="text-ink-gray-4" />
  </div>

  <Git
    v-else-if="openSection?.id === 'github' || openSection?.id === 'github-token'"
    v-model:open-section="openSection"
  />
  <S3Bucket v-else-if="openSection?.id === 's3-bucket'" />
  <LLM v-else-if="openSection?.id === 'llm'" />
  <Notifications v-else-if="openSection?.id === 'notifications'" />
  <Mail v-else-if="openSection?.id === 'mail'" />
  <Workers v-else-if="openSection?.id === 'workers'" />

  <template v-else>
    <ErrorMessage v-if="error" :message="error" class="mb-4" />

    <div class="-mx-2.5 divide-y divide-outline-alpha-gray-1 hover-merges-dividers">
      <SettingsRow
        label="Allow developer mode"
        description="Enables per-site developer mode and code editor."
        interactive
        @click="!saving && toggleAllowDeveloperMode(!allowDeveloperMode)"
      >
        <Switch
          :model-value="allowDeveloperMode"
          :disabled="saving"
          @click.stop
          @update:model-value="toggleAllowDeveloperMode"
        />
      </SettingsRow>

      <SettingsRow
        v-if="liteModeSupported"
        label="Lite mode"
        description="One process for web, realtime and jobs. Less memory, best for small sites."
        interactive
        @click="!saving && toggleLiteMode(!liteMode)"
      >
        <Switch
          :model-value="liteMode"
          :disabled="saving"
          @click.stop
          @update:model-value="toggleLiteMode"
        />
      </SettingsRow>

      <SettingsRow
        v-for="section in sections"
        :key="section.id"
        as="button"
        interactive
        :label="section.label"
        :description="section.description"
        @click="openSection = section"
      >
        <span class="size-4 text-ink-gray-5 lucide-chevron-right" aria-hidden="true" />
      </SettingsRow>

      <Version />
    </div>
  </template>
</template>
