export { GET } from '../route';
