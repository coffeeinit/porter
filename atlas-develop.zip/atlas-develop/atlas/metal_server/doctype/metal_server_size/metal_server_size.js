// Copyright (c) 2026, Frappe and contributors
// For license information, please see license.txt

// frappe.ui.form.on("Metal Server Size", {
// 	refresh(frm) {

// 	},
// });
